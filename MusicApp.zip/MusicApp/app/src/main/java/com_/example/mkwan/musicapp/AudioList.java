package com_.example.mkwan.musicapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class AudioList extends AppCompatActivity {
    TextView fileNameTextView;
    String fileName;
    ListView audioListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio_list);

        fileNameTextView = findViewById(R.id.audio_file_name);
        audioListView = findViewById(R.id.audio_list_view_item);

        final Bundle bundle = getIntent().getExtras();
        if (bundle.containsKey("VoiceRecorder")) {
            fileName = bundle.getString("VoiceRecorder");
            fileNameTextView.setText(fileName);
        } else if (bundle.containsKey("Music")) {
            fileName = bundle.getString("Music");
            fileNameTextView.setText(fileName);
        } else if (bundle.containsKey("SnapTubeAudio")) {
            fileName = bundle.getString("SnapTubeAudio");
            fileNameTextView.setText(fileName);
        } else if (bundle.containsKey("Ringtones")) {
            fileName = bundle.getString("Ringtones");
            fileNameTextView.setText(fileName);
        }

        ArrayList<Audio_List_Name> audioArrayList = new ArrayList<>();
        audioArrayList.add(new Audio_List_Name(getString(R.string.firstAudio)));
        audioArrayList.add(new Audio_List_Name(getString(R.string.secondAudio)));
        audioArrayList.add(new Audio_List_Name(getString(R.string.thirdAudio)));
        audioArrayList.add(new Audio_List_Name(getString(R.string.fourthAudio)));
        audioArrayList.add(new Audio_List_Name(getString(R.string.fifthAudio)));

        Audio_List_Style audioListAdapter = new Audio_List_Style(this, R.layout.audio_file_list_style, audioArrayList);
        audioListView.setAdapter(audioListAdapter);

        audioListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        Intent listenAudioActivity = new Intent(AudioList.this, Listen_Audio.class);
                        listenAudioActivity.putExtra("FirstAudioName", getString(R.string.firstAudio));
                        startActivity(listenAudioActivity);
                        break;
                    case 1:
                        listenAudioActivity = new Intent(AudioList.this, Listen_Audio.class);
                        listenAudioActivity.putExtra("SecondAudioName", getString(R.string.secondAudio));
                        startActivity(listenAudioActivity);
                        break;
                    case 2:
                        listenAudioActivity = new Intent(AudioList.this, Listen_Audio.class);
                        listenAudioActivity.putExtra("ThirdAudioName", getString(R.string.thirdAudio));
                        startActivity(listenAudioActivity);
                        break;
                    case 3:
                        listenAudioActivity = new Intent(AudioList.this, Listen_Audio.class);
                        listenAudioActivity.putExtra("FourthAudioName", getString(R.string.fourthAudio));
                        startActivity(listenAudioActivity);
                        break;
                    case 4:
                        listenAudioActivity = new Intent(AudioList.this, Listen_Audio.class);
                        listenAudioActivity.putExtra("FifthAudioName", getString(R.string.fifthAudio));
                        startActivity(listenAudioActivity);
                        break;
                }
            }
        });
    }
}
