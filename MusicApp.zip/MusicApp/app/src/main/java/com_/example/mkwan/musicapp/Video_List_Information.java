package com_.example.mkwan.musicapp;

public class Video_List_Information {
    private String videoName;
    private Integer imageOfVideos;

    public Video_List_Information(String videoName, Integer imageOfVideos) {
        this.videoName = videoName;
        this.imageOfVideos = imageOfVideos;
    }

    public String getVideoName() {
        return videoName;
    }

    public Integer getImageOfVideos() {
        return imageOfVideos;
    }

    public void setVideoName(String videoName) {
        this.videoName = videoName;
    }

    public void setImageOfVideos(Integer imageOfVideos) {
        this.imageOfVideos = imageOfVideos;
    }
}
