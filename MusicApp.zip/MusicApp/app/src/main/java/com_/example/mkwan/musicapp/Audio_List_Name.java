package com_.example.mkwan.musicapp;

public class Audio_List_Name {
    private String audioName;

    public Audio_List_Name(String audioName) {
        this.audioName = audioName;
    }

    public String getAudioName() {
        return audioName;
    }

    public void setAudioName(String audioName) {
        this.audioName = audioName;
    }
}

