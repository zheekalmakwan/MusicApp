package com_.example.mkwan.musicapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Video_List_Style extends ArrayAdapter<Video_List_Information> {

    private Context context;
    private int resource;
    private ArrayList<Video_List_Information> objects;

    public Video_List_Style(@NonNull Context context, int resource, @NonNull ArrayList<Video_List_Information> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(resource, null);
        }
        TextView file_name = convertView.findViewById(R.id.file_name_text_view);
        ImageView videoImage = convertView.findViewById(R.id.video_Image);
        Video_List_Information videoInformation = objects.get(position);
        file_name.setText(videoInformation.getVideoName());
        videoImage.setImageResource(videoInformation.getImageOfVideos());


        return convertView;
    }
}
