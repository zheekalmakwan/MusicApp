package com_.example.mkwan.musicapp;

public class listOfFiles {
    private String fileName;

    public listOfFiles(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}
