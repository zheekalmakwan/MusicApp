package com_.example.mkwan.musicapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Listen_Audio extends AppCompatActivity {

    TextView audioName;
    ImageView loveImage;
    ImageView audioImage;

    String audioNameTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen__audio);

        audioName = findViewById(R.id.file_name_listen_text_view_audio);
        loveImage = findViewById(R.id.unlove_image_audio);
        audioImage = findViewById(R.id.Image_listen_music_audio);

        audioImage.setImageResource(R.drawable.ic_queue_music_black_24dp);
        Bundle bundle = getIntent().getExtras();
        if (bundle.containsKey("FirstAudioName")) {
            audioNameTextView = bundle.getString("FirstAudioName");
            audioName.setText(audioNameTextView);
        } else if (bundle.containsKey("SecondAudioName")) {
            audioNameTextView = bundle.getString("SecondAudioName");
            audioName.setText(audioNameTextView);
        } else if (bundle.containsKey("ThirdAudioName")) {
            audioNameTextView = bundle.getString("ThirdAudioName");
            audioName.setText(audioNameTextView);
        } else if (bundle.containsKey("FourthAudioName")) {
            audioNameTextView = bundle.getString("FourthAudioName");
            audioName.setText(audioNameTextView);
        } else if (bundle.containsKey("FifthAudioName")) {
            audioNameTextView = bundle.getString("FifthAudioName");
            audioName.setText(audioNameTextView);
        }


        loveImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loveImage.setImageResource(R.drawable.ic_favorite_black_24dp);
            }
        });
    }
}
