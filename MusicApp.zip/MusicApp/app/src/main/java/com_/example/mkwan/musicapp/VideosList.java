
package com_.example.mkwan.musicapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class VideosList extends AppCompatActivity {

    TextView fileNameTextView;
    String fileName;
    ListView videoListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_videos_list);

        fileNameTextView = findViewById(R.id.file_name);
        videoListView = findViewById(R.id.video_list_view_item);

        Bundle bundle = getIntent().getExtras();
        if (bundle.containsKey("VoiceRecorder")) {
            fileName = bundle.getString("VoiceRecorder");
            fileNameTextView.setText(fileName);
        } else if (bundle.containsKey("Music")) {
            fileName = bundle.getString("Music");
            fileNameTextView.setText(fileName);
        } else if (bundle.containsKey("SnapTubeVideo")) {
            fileName = bundle.getString("SnapTubeVideo");
            fileNameTextView.setText(fileName);
        } else if (bundle.containsKey("Ringtones")) {
            fileName = bundle.getString("Ringtones");
            fileNameTextView.setText(fileName);
        }

        ArrayList<Video_List_Information> videoArrayList = new ArrayList<>();
        videoArrayList.add(new Video_List_Information(getString(R.string.firstVideo), R.drawable.allaimagevideo));
        videoArrayList.add(new Video_List_Information(getString(R.string.secondVideo), R.drawable.amozhgareimagevideo));
        videoArrayList.add(new Video_List_Information(getString(R.string.thirdVideo), R.drawable.rajeneimagevideo));
        videoArrayList.add(new Video_List_Information(getString(R.string.fourthVideo), R.drawable.turkyimagevideo));
        videoArrayList.add(new Video_List_Information(getString(R.string.fifthVideo), R.drawable.study));

        Video_List_Style audioListAdapter = new Video_List_Style(this, R.layout.video_file_list_style, videoArrayList);
        videoListView.setAdapter(audioListAdapter);

        videoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        Intent listenAudioActivity = new Intent(VideosList.this, Listen_Video.class);
                        listenAudioActivity.putExtra("FirstVideoName", getString(R.string.firstVideo));
                        startActivity(listenAudioActivity);
                        break;
                    case 1:
                        listenAudioActivity = new Intent(VideosList.this, Listen_Video.class);
                        listenAudioActivity.putExtra("SecondVideoName", getString(R.string.secondVideo));
                        startActivity(listenAudioActivity);
                        break;
                    case 2:
                        listenAudioActivity = new Intent(VideosList.this, Listen_Video.class);
                        listenAudioActivity.putExtra("ThirdVideoName", getString(R.string.thirdVideo));
                        startActivity(listenAudioActivity);
                        break;
                    case 3:
                        listenAudioActivity = new Intent(VideosList.this, Listen_Video.class);
                        listenAudioActivity.putExtra("FourthVideoName", getString(R.string.fourthVideo));
                        startActivity(listenAudioActivity);
                        break;
                    case 4:
                        listenAudioActivity = new Intent(VideosList.this, Listen_Video.class);
                        listenAudioActivity.putExtra("FifthVideoName", getString(R.string.fifthVideo));
                        startActivity(listenAudioActivity);
                        break;
                }
            }
        });
    }
}
