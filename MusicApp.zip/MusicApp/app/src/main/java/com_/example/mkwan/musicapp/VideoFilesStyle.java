package com_.example.mkwan.musicapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class VideoFilesStyle extends ArrayAdapter<listOfFiles> {
    private Context context;
    private int resource;
    private ArrayList<listOfFiles> objects;

    public VideoFilesStyle(@NonNull Context context, int resource, @NonNull ArrayList<listOfFiles> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.objects = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(resource, null);
        }
        TextView file_name = convertView.findViewById(R.id.file_name_text_view);
        listOfFiles filesName = objects.get(position);
        file_name.setText(filesName.getFileName());

        return convertView;
    }
}
