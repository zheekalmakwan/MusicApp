package com_.example.mkwan.musicapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Listen_Video extends AppCompatActivity {

    TextView videoName;
    ImageView loveImage;
    ImageView videoImage;

    String videoNameTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen__video);


        videoName = findViewById(R.id.file_name_listen_text_view_video);
        loveImage = findViewById(R.id.unlove_image_video);
        videoImage = findViewById(R.id.Image_listen_music_video);

        Bundle bundle = getIntent().getExtras();
        if (bundle.containsKey("FirstVideoName")) {
            videoNameTextView = bundle.getString("FirstVideoName");
            videoName.setText(videoNameTextView);
            videoImage.setImageResource(R.drawable.allaimagevideo);
        } else if (bundle.containsKey("SecondVideoName")) {
            videoNameTextView = bundle.getString("SecondVideoName");
            videoName.setText(videoNameTextView);
            videoImage.setImageResource(R.drawable.amozhgareimagevideo);

        } else if (bundle.containsKey("ThirdVideoName")) {
            videoNameTextView = bundle.getString("ThirdVideoName");
            videoName.setText(videoNameTextView);
            videoImage.setImageResource(R.drawable.rajeneimagevideo);
        } else if (bundle.containsKey("FourthVideoName")) {
            videoNameTextView = bundle.getString("FourthVideoName");
            videoName.setText(videoNameTextView);
            videoImage.setImageResource(R.drawable.turkyimagevideo);
        } else if (bundle.containsKey("FifthVideoName")) {
            videoNameTextView = bundle.getString("FifthVideoName");
            videoName.setText(videoNameTextView);
            videoImage.setImageResource(R.drawable.study);
        }


        loveImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loveImage.setImageResource(R.drawable.ic_favorite_black_24dp);
            }
        });
    }
}
