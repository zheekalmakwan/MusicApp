package com_.example.mkwan.musicapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class VideoFiles extends AppCompatActivity {

    ListView videoFilesListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_files);

        videoFilesListView = findViewById(R.id.video_list_view);
        ArrayList<listOfFiles> videoFileArrayList = new ArrayList<>();
        videoFileArrayList.add(new listOfFiles(getString(R.string.voice_recoder)));
        videoFileArrayList.add(new listOfFiles(getString(R.string.music)));
        videoFileArrayList.add(new listOfFiles(getString(R.string.snaptube)));
        videoFileArrayList.add(new listOfFiles(getString(R.string.ringtones)));

        VideoFilesStyle videoFileAdapter = new VideoFilesStyle(this, R.layout.video_file_list_style, videoFileArrayList);

        videoFilesListView.setAdapter(videoFileAdapter);

        videoFilesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapter, View view, int position, long arg) {


                switch (position) {
                    case 0:
                        Intent videoList = new Intent(VideoFiles.this, VideosList.class);
                        videoList.putExtra("VoiceRecorder", getString(R.string.voice_recoder));
                        startActivity(videoList);
                        //  Intent newActivity = new Intent(Parts.this,Item.class);

                        //startActivity(newActivity);
                        break;

                    case 1:
                        videoList = new Intent(VideoFiles.this, VideosList.class);
                        videoList.putExtra("Music", getString(R.string.music));
                        startActivity(videoList);
                        //Intent newActivity2 = new Intent(Parts.this, Item.class);
                        //newActivity2.putExtra("FirstData2", ListElements[1]);

                        //startActivity(newActivity2);
                        break;
                    case 2:
                        videoList = new Intent(VideoFiles.this, VideosList.class);
                        videoList.putExtra("SnapTubeVideo", getString(R.string.snaptube));
                        startActivity(videoList);

                        break;
                    case 3:
                        videoList = new Intent(VideoFiles.this, VideosList.class);
                        videoList.putExtra("Ringtones", getString(R.string.ringtones));
                        startActivity(videoList);

                        break;
                }
            }
        });
    }
}
